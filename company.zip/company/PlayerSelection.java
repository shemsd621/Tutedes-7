package company;
import java.util.ArrayList;
import java.util.Scanner;

public class PlayerSelection {
    public static void main(String[] args) {


        String name;
        int age;
        int type;
        int statistics;

        Player Acc1 = new Player(String name,int age,type,statistics);

//  private String name;
//  private name = name;
//  private age = age;
//  private type = type;
//  private average = avg;
//  private statistics = stat;


        ArrayList<String> players = new ArrayList<String>();
        players.add("Kusal Mendes");
        players.add("Sanath Jayasuriya");
        players.add("Kusal Perera ");
        System.out.println(players);

        String count = null;
        do {
            System.out.println("To Add Player                       :Press A");
            System.out.println("To Get Balling or Batting average   :Press B");
            System.out.println("To Get Player Details               :Press C");
            System.out.println("To Get Best Performance             :Press D");
            System.out.println("To Get Player Type                  :Press E");
            System.out.println("To Get Physical Test Result         :Press F");
            System.out.println("To View All Players                 :Press V");
            System.out.println("To Exit                             :Press Q");

            Scanner input = new Scanner(System.in);
            System.out.print("Press Task Number : ");
            String task_letter = input.next();

            switch (task_letter) {
                case "A":
                    Acc1.AddPlayer();
                    break;
                case "B":
                    Acc1.GetAvg();
                    break;
                case "C":
                    Acc1.GetPlayerDetails();
                    break;
                case "D":
                    Acc1.GetBestPerformance();
                    break;
                case "E":
                    Acc1.GetPlayerType();
                    break;
                case "F":
                    Acc1.GetPhysicalTestResult();
                    break;
                case "V":
                    Acc1.ViewAllPlayers();
                    break;
                case "Q":
                    count = "Q";
            }
        }while(count != "Q");
        System.out.print("Thank you!");


    }
}
