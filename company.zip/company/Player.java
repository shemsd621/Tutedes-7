package company;

import java.util.Scanner;

public class Player {
    String name;
    int age;
    int perform;
    double avg;
    String type;
    String stat;
    String Physical_test_result;


    public Player(String name,int age,int type, int statistics)
    {
        this.name = name;
        this.age = age;
        this.type = String.valueOf(type);
        this.stat = stat;
    }


    public void AddPlayer(){
        Scanner input = new Scanner(System.in);
        System.out.println();

        System.out.print("Enter Player's Name : ");
        String name = input.next();

        System.out.print("Enter player's Age : ");
        int age = input.nextInt();

        System.out.print("Enter Player Type : ");
        String type = input.next();


        System.out.print("Enter Player's statistics : ");
        String stat = input.next();
    }

    public void GetPlayerDetails(){
        System.out.println("Player Name : "+name);
        System.out.println("Age of Player : "+age);
        System.out.println("Player Type : "+type);
    }

    public void GetBestPerformance()
    {
        Scanner input=new Scanner(System.in);
        System.out.print(name+"'s best performance in the past 15 matches : ");
        perform = input.nextInt();
    }

    public void GetPlayerType(){
        System.out.println("============================");
        System.out.println("|    SELECT PLAYER TYPE    |");
        System.out.println("============================");
        System.out.println("|      1. Spin Bowler      |");
        System.out.println("|      2. Seam Bowler      |");
        System.out.println("|      3. Batsman          |");
        System.out.println("|      4. Keeper           |");
        System.out.println("============================");
        Scanner input=new Scanner(System.in);
        System.out.print("Please select the type of player : ");
        int type = input.nextInt();
    }

    public void GetPhysicalTestResult(){
    }

    public void ViewAllPlayers(){
    }

    public void GetAvg()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the batting or bowling average of "+name+" : ");
        avg = input.nextDouble();
    }


}


