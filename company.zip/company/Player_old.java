package company;

import java.util.Scanner;

public class Player_old {
    public String statistics;
    public String playerName;
    public int age;
    public String type;
    public int runs;
    public int wickets;
    public int catches;
    public int stump;
    public int four;
    public int six;
    public int highScore;
    public int notOuts;
    public int perform;
    public double rate;
    public double strike;
    public double economy;
    public double bowl;
    public double bat;

    public Player_old()
    {
        this.playerName = playerName;
        this.age = age;
        this.type = type;
        this.statistics = statistics;
    }

    public void display ()
    {
        System.out.println("Player Name : "+playerName);
        System.out.println("Age of Player : "+age);
        System.out.println("Player Type : "+type);
    }

    public void runsScored()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the runs scored by "+playerName+" in the past 15 matches : ");
        runs = input.nextInt();
    }

    public void wicketsScored()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the wickets scored by "+playerName+" in the past 15 matches : ");
        wickets = input.nextInt();
    }

    public void catchesTaken()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the number of catches taken by "+playerName+" in the past 15 matches : ");
        catches = input.nextInt();
    }

    public void stumpMade()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the number of stumps made by "+playerName+" in the past 15 matches : ");
        stump = input.nextInt();
    }

    public void fours()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the number of 4's scored by "+playerName+" in the past 15 matches : ");
        four = input.nextInt();
    }

    public void sixes()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the number of 6's scored by "+playerName+" in the past 15 matches : ");
        six = input.nextInt();
    }

    public void highestScore()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the highest score of "+playerName+" in the past 15 matches : ");
        highScore = input.nextInt();
    }

    public void notOuts()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the number of times "+playerName+" was not out in the past 15 matches : ");
        six = input.nextInt();
    }

    public void bestPerform()
    {
        Scanner input=new Scanner(System.in);
        System.out.print(playerName+"'s best performance in the past 15 matches : ");
        perform = input.nextInt();
    }

    public void runRate()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the run rate of "+playerName+" : ");
        rate = input.nextDouble();
    }

    public void strikeRate()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the strike rate of "+playerName+" : ");
        strike = input.nextDouble();
    }

    public void economyRate()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the economy rate of "+playerName+" : ");
        economy = input.nextDouble();
    }

    public void bowlingAvg()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the bowling average of "+playerName+" : ");
        bowl = input.nextDouble();
    }

    public void battingAvg()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the batting average of "+playerName+" : ");
        bat = input.nextDouble();
    }

}